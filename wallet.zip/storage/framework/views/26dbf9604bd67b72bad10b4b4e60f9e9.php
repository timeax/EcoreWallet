<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp\htdocs\Github\wallet\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>