import React from 'react';

const FloatingActions: React.FC<FloatingActionsProps> = () => {
    //--- code here ---- //
    return (
        <div>

        </div>
    );
}

interface FloatingActionsProps {

}

export default FloatingActions
